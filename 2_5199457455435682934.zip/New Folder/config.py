
bot_token = '2074663702:AAGs436GZMlJZDo3dVJj0B-5NWbs79xcE7k'
bot_tokens = '2066860768:AAEDzTMZgTgVsvh_j96q8MlDSzYcFA_5mGI'

bd_host = '141.8.192.170'


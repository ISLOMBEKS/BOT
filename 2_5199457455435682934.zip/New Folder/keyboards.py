import telebot
from telebot import types

main = telebot.types.ReplyKeyboardMarkup(True)
main.row('Накрутить')
main.row('Профиль','Информация')

otmena = telebot.types.ReplyKeyboardMarkup(True)
otmena.row('Отмена')

# -*- coding: utf-8 -*-
from decimal import *
import telebot
import datetime
from telebot import types, apihelper
import sqlite3
import random, string
import time
import os,random,shutil,subprocess
import json
import keyboards
import requests
from datetime import datetime, timedelta
from datetime import date
from dateutil.relativedelta import relativedelta
import secrets
import hashlib
import config
from getpass import getpass
from mysql.connector import connect, Error
import pytz



bot = telebot.TeleBot('2066860768:AAEDzTMZgTgVsvh_j96q8MlDSzYcFA_5mGI')
print(bot.get_me().username)
bot_name = bot.get_me().username

@bot.message_handler(commands=['start'])
def start_message(message):
	if message.chat.type == 'private':
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()
		q.execute(f'SELECT * FROM ugc_users WHERE id = "{message.chat.id}" and bot = "{bot_name}"')
		row = q.fetchall()
		if str(row) == '[]':
			q.execute("INSERT INTO ugc_users (id,bot) VALUES ('%s','%s')"%(message.chat.id,bot_name))
			connection.commit()
		bot.send_message(message.chat.id,f'👑 Добро пожаловать!',parse_mode='HTML',reply_markup=keyboards.main)



@bot.message_handler(content_types=['text'])
def send_text(message):
	if message.chat.type == 'private':

		if message.text == '🤖 Мой боты':
			connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
			q = connection.cursor()
			keyboard = types.InlineKeyboardMarkup()
			q.execute(f"SELECT * FROM list_bot where user = '{message.chat.id}'")
			rows = q.fetchall()
			for i in rows:
				keyboard.add(types.InlineKeyboardButton(text=i[2],callback_data=f'bot_ {i[0]}'))
			keyboard.add(types.InlineKeyboardButton(text='➕ Добавить бот',callback_data=f'add_bot'))	
			bot.send_message(message.chat.id, f'''◾️ Выберите нужный бот или добавьте новый:''',parse_mode='HTML', reply_markup=keyboard)


# 		elif message.text == 'Профиль':
# 			connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
# 			q = connection.cursor()
# 			q.execute(f'SELECT * FROM ugc_users WHERE id = "{message.chat.id}" and bot = "{bot_name}"')
# 			row = q.fetchone()
# 			keyboard = types.InlineKeyboardMarkup()
# 			keyboard.add(types.InlineKeyboardButton(text='📥 Пополнить баланс',callback_data=f'awhat_oplata'))
# 			keyboard.add(types.InlineKeyboardButton(text='👤 Реферальная система',callback_data='ref'))
# 			keyboard.add(types.InlineKeyboardButton(text='🔎 Проверить заказ',callback_data='Проверить'))
# 			bot.send_message(message.chat.id, f'''🆔 Ваш id: <code>{message.chat.id}</code>

# 💵 Баланс: <code>{row[1]}</code>
# ''',parse_mode='HTML', reply_markup=keyboard)
# 			return

# 		elif message.text == 'Информация':
# 			connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
# 			q = connection.cursor()
# 			q.execute(f'SELECT * FROM config WHERE bot = "{bot_name}"')
# 			row = q.fetchone()
# 			bot.send_message(message.chat.id, row[2] ,parse_mode='HTML',reply_markup=keyboards.main)
# 			return

def poisk_user(message,bot_id):
	if message.text.lower() != 'отмена':
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()
		q.execute(f"SELECT * FROM list_bot where id = '{bot_id}'")
		rows = q.fetchone()
		bot_name = rows[6]
		q.execute(f"SELECT * FROM ugc_users where id = '{message.text}'and bot = '{bot_name}' ")
		row = q.fetchone()
		bot.send_message(message.chat.id, '<b>🔍 Ищем...</b>',parse_mode='HTML', reply_markup=keyboards.main)
		if row != None:
			keyboard = types.InlineKeyboardMarkup()
			keyboard.add(types.InlineKeyboardButton(text='🔒 Заблокировать | Раблокировать',callback_data=f'заблокировать_ {bot_name} {row[0]}'))
			keyboard.add(types.InlineKeyboardButton(text='⬅️ Назад',callback_data=f'бот '))	
			msg = bot.send_message(message.chat.id, f'''👤 Пользователь: 
🆔 ID: <code>{row[0]}</code>
💰 Баланс: <code>{row[1]}</code>
🔐 Статус: <code>{row[4]}</code>
''',parse_mode='HTML',reply_markup=keyboard)

		else:
			keyboard = types.InlineKeyboardMarkup()
			keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'bot_ {bot_id}'))
			bot.send_message(message.chat.id, '<b>Нет такого пользователя</b>',parse_mode='HTML')
	else:
		keyboard = types.InlineKeyboardMarkup()
		keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'bot_ {bot_id}'))
		bot.send_message(message.chat.id, '<b>Отменили</b>',parse_mode='HTML')

def generator_pw():
    pwd =  string.digits
    return "".join(random.choice(pwd) for x in range(random.randint(10, 16)))

def edit_procent(message,bot_id):
	bot.delete_message(message.chat.id,message.message_id)
	if message.text != 'Отмена':
		if message.text.isdigit() == True:
			connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
			q = connection.cursor()
			q.execute(f"update list_bot set prace = '{message.text}' where id = '{bot_id}'")
			connection.commit()
			keyboard = types.InlineKeyboardMarkup()
			keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'bot_ {bot_id}'))
			bot.send_message(message.chat.id, '✔️ Вы успешно сменили наценку', reply_markup=keyboard)
		else:
			keyboard = types.InlineKeyboardMarkup()
			keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'bot_ {bot_id}'))
			bot.send_message(message.chat.id, '✖️ Указывать необходимо целое число', reply_markup=keyboard)

	else:
		bot.send_message(message.chat.id, '✖️ Вернулись на главную', reply_markup=keyboards.main)

def add_bot(message):
	bot.delete_message(message.chat.id,message.message_id)
	if message.text != 'Отмена':
			bot.send_message(message.chat.id, '⏳Идет создание бота....', reply_markup=keyboards.main)
			try:
				bot_create = telebot.TeleBot(message.text)
				user = message.chat.id
				name = bot_create.get_me().first_name
				balance = 0
				info = 'Текст'
				prace = 10
				bots = bot_create.get_me().username
				bot_token = message.text
				status = 'Работает'
				logi = 'On'
				current_dir = os.getcwd()
				print(current_dir)

				path = f'{current_dir}/bot_list/{bots}'
				os.makedirs(path, exist_ok=True)

				src = f'{current_dir}/bot/main.py'
				shutil.copy(src, path ,follow_symlinks=True)
				src = f'{current_dir}/bot/keyboards.py'
				shutil.copy(src, path ,follow_symlinks=True)
				my_file = open(f"{bots}.service", "a+")
				my_file.write(f'''[Unit]
Description={bots}
After=syslog.target
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory={current_dir}/bot_list/{bots}
ExecStart=/usr/bin/python3 /{current_dir}/bot_list/{bots}/main.py
RestartSec=10
Restart=always
 
[Install]
WantedBy=multi-user.target''')
				my_file.close()
				src = f'{current_dir}/{bots}.service'
				shutil.copy(src, '/etc/systemd/system/' ,follow_symlinks=True)
				cmd = f'systemctl enable {bots}'
				cmd1 = f'systemctl start {bots}'
				subprocess.Popen(cmd1, shell=True)
				subprocess.Popen(cmd, shell=True)
				path = os.path.join(os.path.abspath(os.path.dirname(__file__)), f'{bots}.service')
				os.remove(path)
				connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
				q = connection.cursor()
				q.execute("INSERT INTO list_bot (user,name,balance,info,prace,bot,bot_token,status,logi) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s')"%(user,name,balance,info,prace,bots,bot_token,status,logi))
				connection.commit()
				keyboard = types.InlineKeyboardMarkup()
				keyboard.add(types.InlineKeyboardButton(text='Настроить бот',callback_data=f'бот '))
				bot.send_message(message.chat.id, f'''Бот @{bots} успешно подключен к Name service.''', reply_markup=keyboard)
			except:
				bot.send_message(message.chat.id, '✖️ Ошибка создания бота', reply_markup=keyboards.main)


	else:
		bot.send_message(message.chat.id, '✖️ Вернулись на главную', reply_markup=keyboards.main)

@bot.callback_query_handler(func=lambda call: True)
def handler_call(call):
	a = call.data.split()
	if a[0] == 'бот':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()
		keyboard = types.InlineKeyboardMarkup()
		q.execute(f"SELECT * FROM list_bot where user = '{call.message.chat.id}'")
		rows = q.fetchall()
		for i in rows:
			keyboard.add(types.InlineKeyboardButton(text=i[2],callback_data=f'bot_ {i[0]}'))
		keyboard.add(types.InlineKeyboardButton(text='➕ Добавить бот',callback_data=f'add_bot'))	
		bot.send_message(call.message.chat.id, f'''◾️ Выберите нужный бот или добавьте новый:''',parse_mode='HTML', reply_markup=keyboard)

	if a[0] == 'bot_':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()
		q.execute(f"SELECT * FROM list_bot where id = '{a[1]}'")
		rows = q.fetchone()
		q.execute(f"SELECT COUNT(id) FROM ugc_users where bot = '{rows[6]}'")
		user_count = q.fetchone()[0]
		q.execute(f"SELECT COUNT(id) FROM list_zakaz where bot = '{rows[6]}'")
		zakaz_count = q.fetchone()[0]
		status = "🔴 Выключить" if rows[8] == "Работает" else "🟢 Включить"
		keyboard = types.InlineKeyboardMarkup()
		keyboard.add(types.InlineKeyboardButton(text='💬 Рассылка',callback_data=f'Рассылка {rows[0]}'),types.InlineKeyboardButton(text='🔎 Поиск пользователя',callback_data=f'Поиск {rows[0]}'))
		keyboard.add(types.InlineKeyboardButton(text='💲 Сменить наценку',callback_data=f'Наценка {rows[0]}'),types.InlineKeyboardButton(text='📈 Последние заказы',callback_data=f'заказы {rows[0]}'))
		keyboard.add(types.InlineKeyboardButton(text=f'{status}' ,callback_data=f'статусбот {rows[0]}'),types.InlineKeyboardButton(text='🗑 Удалить бот',callback_data=f'Удалитьбот {rows[0]}'))
		bot.send_message(call.message.chat.id, f'''▪️ Бот: @{rows[6]}
▪️ Всего пользователей: {user_count}
▪️ Новые пользователи: {user_count}
▪️ Заказов: {zakaz_count} шт
▪️ Заказов за сегодня : {zakaz_count} шт
▪️ Последний заказ: None
▪️ Наценка: {rows[5]} %
▪️ Прибыль: {rows[10]}
▪️ Прибыль cегодня: {rows[10]}
▪️ Баланс бота: {rows[3]}
▪️ Статус бота: {rows[8]}
▪️ Уведомления о заказах: {rows[9]}''',parse_mode='HTML', reply_markup=keyboard)

	if a[0] == 'Поиск':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		msg = bot.send_message(call.message.chat.id, "<b>ℹ️ Укажите id пользователя:</b>",parse_mode='HTML', reply_markup=keyboards.main)
		bot.register_next_step_handler(msg, poisk_user, a[1])

	if a[0] == 'заблокировать_':
		print(a[1])
		print(a[2])
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()

		q.execute(f"SELECT status FROM ugc_users where id = '{a[2]}' and bot = '{a[1]}'")
		status = q.fetchone()[0]

		if status == 'Активен':
			q.execute(f"update ugc_users set status = 'Заблокирован' where id = '{a[2]}' and bot = '{a[1]}'")
			connection.commit()
			bot.answer_callback_query(callback_query_id=call.id, text="✅ Заблокирован")
		else:
			q.execute(f"update ugc_users set status = 'Активен' where id = '{a[2]}' and bot = '{a[1]}'")
			connection.commit()
			bot.answer_callback_query(callback_query_id=call.id, text="✅ Разблокирован")



	if a[0] == 'Удалитьбот':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()
		keyboard = types.InlineKeyboardMarkup()
		q.execute(f"DELETE FROM list_bot where id = '{a[1]}'")
		connection.commit()
		keyboard.add(types.InlineKeyboardButton(text='⬅️ Назад',callback_data=f'бот '))	
		bot.send_message(call.message.chat.id, f'''✔️ Готово''',parse_mode='HTML', reply_markup=keyboard)

	if a[0] == 'статусбот':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		connection = connect(host=config.bd_host,user=config.bd_login,password=config.bd_pass,database=config.bd_base)
		q = connection.cursor()
		q.execute(f"SELECT * FROM list_bot where id = '{a[1]}'")
		rows = q.fetchone()
		if rows[8] == 'Работает':
			q.execute(f"update list_bot set status = 'Выключен' where id = '{a[1]}'")
			connection.commit()
			cmd = f'systemctl stop {rows[6]}'
			subprocess.Popen(cmd, shell=True)

		if rows[8] == 'Выключен':
			q.execute(f"update list_bot set status = 'Работает' where id = '{a[1]}'")
			connection.commit()
			cmd = f'systemctl start {rows[6]}'
			subprocess.Popen(cmd, shell=True)
		keyboard = types.InlineKeyboardMarkup()	
		keyboard.add(types.InlineKeyboardButton(text='⬅️ Назад',callback_data=f'бот '))	
		bot.send_message(call.message.chat.id, f'''✔️ Готово''',parse_mode='HTML', reply_markup=keyboard)

	if a[0] == 'Наценка':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		
		msg = bot.send_message(call.message.chat.id, "🔬<b>Напишите процент на который хотите поднять цену:</b>",parse_mode='HTML', reply_markup=keyboards.main)
		bot.register_next_step_handler(msg, edit_procent, a[1])

	if a[0] == 'add_bot':
		bot.delete_message(call.message.chat.id,call.message.message_id)
		msg = bot.send_message(call.message.chat.id, '''Чтобы подключить бот, вам нужно выполнить два действия:

1. Перейдите в @BotFather и <a href="https://telegra.ph/Sozdat-bot-10-19">создайте новый бот</a>.
2. После создания бота вы получите токен (12345:6789ABCDEF) — скопируйте и отправьте его в этот чат.

Важно: не подключайте боты, которые уже используются другими сервисами (Controller Bot, разные CRM и т.д.)''',disable_web_page_preview = True,parse_mode='HTML', reply_markup=keyboards.otmena)
		bot.register_next_step_handler(msg, add_bot)


bot.polling(True)


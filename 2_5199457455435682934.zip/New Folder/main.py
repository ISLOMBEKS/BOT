# -*- coding: utf-8 -*-
from decimal import *
import telebot
import datetime
from telebot import types, apihelper
import sqlite3
import random, string
import time
import os,random,shutil,subprocess
import json
import keyboards
import requests
from datetime import datetime, timedelta
from datetime import date
from dateutil.relativedelta import relativedelta
import secrets
import hashlib
from getpass import getpass
from mysql.connector import connect, Error
import pytz



botnames = os.path.basename(os.path.abspath(os.path.dirname(__file__)))
connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
q = connection.cursor()
q.execute(f'SELECT bot_token FROM list_bot WHERE bot = "{botnames}"')
bot_token = q.fetchone()[0]
bot = telebot.TeleBot(bot_token)
bot_name = bot.get_me().username

@bot.message_handler(commands=['start'])
def start_message(message):
	if message.chat.type == 'private':
		connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
		q = connection.cursor()
		q.execute(f'SELECT * FROM ugc_users WHERE id = "{message.chat.id}" and bot = "{bot_name}"')
		row = q.fetchall()
		if str(row) == '[]':
			q.execute("INSERT INTO ugc_users (id,bot) VALUES ('%s','%s')"%(message.chat.id,bot_name))
			connection.commit()
			if message.text[7:] != '':
				if message.text[7:] != userid:
					q.execute(f"update ugc_users set ref = '{message.text[7:]}' where id = {message.chat.id} and bot = '{bot_name}'")
					connection.commit()
					bot.send_message(message.text[7:], f'➕ Новый реферал: @{message.from_user.username}',reply_markup=keyboards.main)
		bot.send_message(message.chat.id,f'👑 Добро пожаловать!',parse_mode='HTML',reply_markup=keyboards.main)

		
@bot.message_handler(content_types=['text'])
def send_text(message):
	if message.chat.type == 'private':
		if message.text == 'Накрутить':
			connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
			q = connection.cursor()
			keyboard = types.InlineKeyboardMarkup()
			q.execute(f"SELECT * FROM category")
			rows = q.fetchall()
			btns = []
			for i in range(len(rows)):
				btns.append(types.InlineKeyboardButton(text=rows[i][0], callback_data=f'sub_category_{rows[i][1]}'))
			while btns != []:
				try:
					keyboard.add(
						btns[0],
						btns[1]
						)
					del btns[1], btns[0]
				except:
					keyboard.add(btns[0])
					del btns[0]
			bot.send_message(message.chat.id, f'''◾️ Выберите нужный пункт меню:''',parse_mode='HTML', reply_markup=keyboard)
			return

		elif message.text == 'Профиль':
			connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
			q = connection.cursor()
			q.execute(f'SELECT * FROM ugc_users WHERE id = "{message.chat.id}" and bot = "{bot_name}"')
			row = q.fetchone()
			keyboard = types.InlineKeyboardMarkup()
			keyboard.add(types.InlineKeyboardButton(text='📥 Пополнить баланс',callback_data=f'awhat_oplata'))
			keyboard.add(types.InlineKeyboardButton(text='👤 Реферальная система',callback_data='ref'))
			keyboard.add(types.InlineKeyboardButton(text='🔎 Проверить заказ',callback_data='Проверить'))
			bot.send_message(message.chat.id, f'''🆔 Ваш id: <code>{message.chat.id}</code>

💵 Баланс: <code>{row[1]}</code>
''',parse_mode='HTML', reply_markup=keyboard)
			return

		elif message.text == 'Информация':
			connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
			q = connection.cursor()
			q.execute(f'SELECT * FROM config WHERE bot = "{bot_name}"')
			row = q.fetchone()
			bot.send_message(message.chat.id, row[2] ,parse_mode='HTML',reply_markup=keyboards.main)
			return


def generator_pw():
    pwd =  string.digits
    return "".join(random.choice(pwd) for x in range(random.randint(10, 16)))

def btc_oplata_1(message):
	if message.text != 'Отмена':
		try:
			if int(message.text) >= int(1):
				connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
				q = connection.cursor()
				id_pay = generator_pw()
				awfawf = f"{message.text}|{id_pay}|{config.id_key_payok}|RUB|Пополнение баланса|{config.api_key_payok}"
				hash = hashlib.md5(awfawf.encode("utf-8")).hexdigest()
				url = f'https://payok.io/pay?amount={message.text}&payment={id_pay}&shop={config.id_key_payok}&desc=%D0%9F%D0%BE%D0%BF%D0%BE%D0%BB%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%B1%D0%B0%D0%BB%D0%B0%D0%BD%D1%81%D0%B0&sign={hash}'
				q.execute("INSERT INTO pay_ok (user,id_pay) VALUES ('%s', '%s')"%(message.chat.id,id_pay))
				connection.commit()
				keyboard = types.InlineKeyboardMarkup()
				keyboard.add(types.InlineKeyboardButton(text=f'''↗️ Перейти к оплате ''',url=url))
				keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'profale'))
				bot.send_message(message.chat.id, '''▪️  Для пополнения баланса перейдите по ссылке и оплатите счет удобным способом !

💡 После оплаты вы получите уведомление о успешной оплате в течений 1 минуты.''', reply_markup=keyboard)
			else:
				bot.send_message(message.chat.id, f'✖️ Минимальная сумма пополнения 2 RUB',parse_mode='HTML', reply_markup=keyboards.main)
		except Exception as e:
			keyboard = types.InlineKeyboardMarkup()
			keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'profale'))
			bot.send_message(message.chat.id, f'✖️ Минимальная сумма пополнения 2 RUB',parse_mode='HTML', reply_markup=keyboard)

	else:
		bot.send_message(message.chat.id, 'Вернулись на главную', reply_markup=keyboards.main)


@bot.callback_query_handler(func=lambda call:True)
def podcategors(call):

	if call.data == 'awhat_oplata':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		keyboard = types.InlineKeyboardMarkup()
		keyboard.add(types.InlineKeyboardButton(text=f'''▪️ Qiwi''',callback_data='add_depozit'),types.InlineKeyboardButton(text=f'''▪️ Card''',callback_data='add_depozit'),types.InlineKeyboardButton(text=f'''▪️ Юmoney''',callback_data='add_depozit'))
		keyboard.add(types.InlineKeyboardButton(text=f'''▪️ Perfect Money''',callback_data='add_depozit'),types.InlineKeyboardButton(text=f'''▪️ Sim''',callback_data='add_depozit'),types.InlineKeyboardButton(text=f'''▪️ Crypto''',callback_data='add_depozit'))
		keyboard.add(types.InlineKeyboardButton(text=f'''⬅️ Назад''',callback_data=f'profale'))
		bot.send_message(call.message.chat.id, f'''▪️ Выберите метод для пополнения баланса:''',parse_mode='HTML', reply_markup=keyboard)

	elif call.data == 'add_depozit':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		msg = bot.send_message(call.message.chat.id,'''ℹ️ Укажите сумму пополнения:''', reply_markup=keyboards.main, parse_mode='HTML')
		bot.register_next_step_handler(msg, btc_oplata_1)

	elif call.data[:13] == 'sub_category_':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		sub_category_id = call.data[13:]
		connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
		q = connection.cursor()
		keyboard = types.InlineKeyboardMarkup()
		q.execute(f"SELECT * FROM sub_category where category = '{sub_category_id}'")
		rows = q.fetchall()
		for i in rows:
			keyboard.add(types.InlineKeyboardButton(text=i[0],callback_data=f'item_{i[2]}'))
		bot.send_message(call.message.chat.id, f'''◾️ Выберите нужный пункт меню:''',parse_mode='HTML', reply_markup=keyboard)

	elif call.data[:5] == 'item_':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		item_id = call.data[5:]
		connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
		q = connection.cursor()
		keyboard = types.InlineKeyboardMarkup()
		q.execute(f"SELECT * FROM item where sub_category = '{item_id}'")
		rows = q.fetchall()
		for i in rows:
			keyboard.add(types.InlineKeyboardButton(text=i[0],callback_data=f'usluga_{i[8]}'))
		bot.send_message(call.message.chat.id, f'''◾️ Выберите нужный пункт меню:''',parse_mode='HTML', reply_markup=keyboard)

	elif call.data[:7] == 'usluga_':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		usluga__id = call.data[7:]
		connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
		q = connection.cursor()
		q.execute(f"update ugc_users set usluga = '{usluga__id}' where id = '{call.message.chat.id}' and bot = '{bot_name}'")
		connection.commit()
		keyboard = types.InlineKeyboardMarkup()
		q.execute(f"SELECT * FROM item where item_id = '{usluga__id}'")
		rows = q.fetchone()
		keyboard.add(types.InlineKeyboardButton(text='Заказать',callback_data=f'zakazat'))
		bot.send_message(call.message.chat.id, f'''{rows[7]} 

Минимальное количество: {rows[4]}
Максимальное количество: {rows[5]}

Цена за 1000: {rows[3]} RUB''',parse_mode='HTML', reply_markup=keyboard)

	elif call.data == 'zakazat':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
		q = connection.cursor()
		keyboard = types.InlineKeyboardMarkup()
		q.execute(f"SELECT usluga FROM ugc_users where where id = '{call.message.chat.id}' and bot = '{bot_name}")
		usluga__id = q.fetchone()[0]
		q.execute(f"SELECT * FROM item where item_id = '{usluga__id}'")
		rows = q.fetchone()
		keyboard.add(types.InlineKeyboardButton(text='Заказать',callback_data=f'zakazat'))
		bot.send_message(call.message.chat.id, f'''👉 Введите количество которое хотите купить:''',parse_mode='HTML', reply_markup=keyboards.otmena)
	
	elif call.data == "Проверить":
		msg= bot.send_message(call.message.chat.id, "🔬<b>Напишите номер вашего заказа:</b>",parse_mode='HTML', reply_markup=keyboards.main)
		bot.register_next_step_handler(msg, statuszakaz)

			
	elif call.data == 'ref':
		bot.delete_message(chat_id=call.message.chat.id,message_id=call.message.message_id)
		connection = connect(host=bd_host,user=bd_login,password=bd_pass,database=bd_base)
		q = connection.cursor()
		q.execute(f'SELECT COUNT(id) FROM ugc_users WHERE ref = "{call.message.chat.id}" and bot = "{bot_name}"')
		user_ref_count = q.fetchone()[0]
		bot.send_message(call.message.chat.id, f'''🗣 Партнерская программа

💸 Чтобы пассивно капали деньги на баланс, многого не нужно. Зови друзей и получай с них монету😉

📈 У вас: {user_ref_count} реферал(ов).

🌐 Ссылка для приглашения: https://t.me/{bot_name}?start={call.message.chat.id}

❗️Вы получаете 4% с трат рефералов.''',reply_markup=keyboards.main, disable_web_page_preview=True)	


bot.polling(True)

